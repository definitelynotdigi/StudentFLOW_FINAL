<?php
session_start();

// Only accept POST + valid CSRF
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}

$posted = $_POST['csrf_token'] ?? '';
if (empty($posted) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $posted)) {
    header("Location: index.php?login_error=csrf");
    exit();
}

/* ---------- Record student logout BEFORE destroying session ---------- */
if (!empty($_SESSION['user_id']) && (($_SESSION['role'] ?? '') === 'Student')) {
    try {
        require_once __DIR__ . '/database.php';
        $uid = (int)$_SESSION['user_id'];

        $stu = $pdo->prepare("SELECT student_id FROM users WHERE id = ? LIMIT 1");
        $stu->execute([$uid]);
        $stu_code = (string)$stu->fetchColumn();

        $pdo->prepare("
            INSERT INTO student_logout_logs
                (student_user_id, student_id, logout_at, session_id)
            VALUES (?, ?, NOW(), ?)
        ")->execute([$uid, $stu_code, session_id()]);
    } catch (Throwable $e) {
        error_log('[student_logout_log] ' . $e->getMessage());
    }
}

$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();
header("Location: index.php");
exit();