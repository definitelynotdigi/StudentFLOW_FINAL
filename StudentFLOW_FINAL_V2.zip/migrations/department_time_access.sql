USE student_portal_db;

/* =============================================================================
   DEPARTMENT ACCESS CREDENTIALS
   One active row per Department user. Stores ONLY the bcrypt hash.
   ============================================================================= */
CREATE TABLE IF NOT EXISTS department_access_credentials (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_user_id  INT UNSIGNED NOT NULL,
    department_id       VARCHAR(50)  NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    is_active           TINYINT(1)   NOT NULL DEFAULT 1,
    failed_attempts     INT          NOT NULL DEFAULT 0,
    lockout_until       DATETIME     DEFAULT NULL,
    last_password_change DATETIME    DEFAULT NULL,
    created_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_dept_credential (department_user_id, is_active),
    INDEX idx_dept_cred_id (department_id),
    CONSTRAINT fk_dept_cred_user
        FOREIGN KEY (department_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/* =============================================================================
   DEPARTMENT TIME LOGS
   One active row per Department user at a time.
   Status: active | completed | manual_closed
   ============================================================================= */
CREATE TABLE IF NOT EXISTS department_time_logs (
    id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_user_id INT UNSIGNED NOT NULL,
    department_id      VARCHAR(50)  NOT NULL,
    time_in            DATETIME     NOT NULL,
    time_out           DATETIME     DEFAULT NULL,
    duration_seconds   INT          DEFAULT NULL,
    status             ENUM('active','completed','manual_closed') NOT NULL DEFAULT 'active',
    closed_by_user_id  INT UNSIGNED DEFAULT NULL,
    close_reason       VARCHAR(255) DEFAULT NULL,
    ip_address         VARBINARY(16) DEFAULT NULL,   -- packed inet_pton, optional
    user_agent         VARCHAR(255) DEFAULT NULL,
    created_at         TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_dtl_user    (department_user_id),
    INDEX idx_dtl_status  (status),
    INDEX idx_dtl_time_in (time_in),
    INDEX idx_dtl_dept    (department_id),
    CONSTRAINT fk_dtl_user
        FOREIGN KEY (department_user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_dtl_closed_by
        FOREIGN KEY (closed_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/* DB-level guard: at most one active log per department user.
   MySQL 8 functional unique index on a generated column. */
ALTER TABLE department_time_logs
    ADD COLUMN active_guard TINYINT
        GENERATED ALWAYS AS (IF(status='active', 1, NULL)) STORED,
    ADD UNIQUE KEY uniq_active_per_user (department_user_id, active_guard);