USE student_portal_db;

/* =============================================================================
   STUDENT LOGIN LOGS — records every successful student login
   ============================================================================= */
CREATE TABLE IF NOT EXISTS student_login_logs (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_user_id   INT UNSIGNED NOT NULL,
    student_id        VARCHAR(50)  NOT NULL,
    login_at          DATETIME     NOT NULL,
    ip_address        VARBINARY(16) DEFAULT NULL,
    user_agent        VARCHAR(255) DEFAULT NULL,
    session_id        VARCHAR(128) DEFAULT NULL,
    created_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sll_student (student_user_id),
    INDEX idx_sll_student_code (student_id),
    INDEX idx_sll_login_at (login_at),
    CONSTRAINT fk_sll_student FOREIGN KEY (student_user_id)
        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS student_logout_logs (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_user_id   INT UNSIGNED NOT NULL,
    student_id        VARCHAR(50)  NOT NULL,
    logout_at         DATETIME     NOT NULL,
    session_id        VARCHAR(128) DEFAULT NULL,
    created_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sll_logout_at (logout_at),
    INDEX idx_sll_logout_user (student_user_id),
    CONSTRAINT fk_sll_logout_student FOREIGN KEY (student_user_id)
        REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'Migration complete' AS status;

/* =============================================================================
   DEPARTMENT ACCESS CREDENTIALS — add OTP columns for forgot-password flow
   ============================================================================= */
SET @sql := (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'department_access_credentials'
       AND COLUMN_NAME = 'reset_otp') = 0,
  'ALTER TABLE department_access_credentials
     ADD COLUMN reset_otp VARCHAR(10) DEFAULT NULL,
     ADD COLUMN reset_otp_expires DATETIME DEFAULT NULL,
     ADD COLUMN reset_otp_attempts INT NOT NULL DEFAULT 0',
  'SELECT 1'));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'Migration complete' AS status;