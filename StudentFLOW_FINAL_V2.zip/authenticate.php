<?php
session_start();
date_default_timezone_set('Asia/Manila');

require_once 'database.php';

/* CSRF verification — must be checked BEFORE anything else */
if (
    empty($_POST['csrf_token']) ||
    empty($_SESSION['csrf_token']) ||
    !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
) {
    header("Location: index.php?login_error=csrf");
    exit();
}

$identity = trim($_POST['identity'] ?? '');
$password = $_POST['password'] ?? '';

if ($identity === '' || $password === '') {
    header("Location: index.php?login_error=empty");
    exit();
}

$stmt = $pdo->prepare("SELECT id, username, password_hash, role, failed_attempts, lockout_until FROM users WHERE username = ? OR email = ?");
$stmt->execute([$identity, $identity]);
$user = $stmt->fetch();

if ($user) {

    /* ---------- Lockout check ---------- */
    $lock_check = $pdo->prepare("SELECT lockout_until, NOW() AS db_now FROM users WHERE id = ?");
    $lock_check->execute([$user['id']]);
    $lk = $lock_check->fetch();

    if ($lk['lockout_until'] && $lk['lockout_until'] > $lk['db_now']) {
        header("Location: index.php?login_error=locked");
        exit();
    }

    // If lockout has expired, reset the counter
    if ($lk['lockout_until'] && $lk['lockout_until'] <= $lk['db_now']) {
        $pdo->prepare("UPDATE users SET failed_attempts = 0, lockout_until = NULL WHERE id = ?")
            ->execute([$user['id']]);
        $user['failed_attempts'] = 0;
    }

    /* ---------- Password verify ---------- */
    if (password_verify($password, $user['password_hash'])) {

        $reset_stmt = $pdo->prepare("UPDATE users SET failed_attempts = 0, lockout_until = NULL WHERE id = ?");
        $reset_stmt->execute([$user['id']]);

        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['last_activity'] = time();

        /* ---------- Record student login ---------- */
        if (strtolower($user['role']) === 'student') {
            try {
                $stu_stmt = $pdo->prepare("SELECT student_id FROM users WHERE id = ? LIMIT 1");
                $stu_stmt->execute([$user['id']]);
                $stu_code = (string)$stu_stmt->fetchColumn();

                $ip = $_SERVER['REMOTE_ADDR'] ?? '';
                $packed_ip = $ip !== '' ? @inet_pton($ip) : null;
                $ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
                $sess_id = session_id();

                $ins = $pdo->prepare("
                    INSERT INTO student_login_logs
                        (student_user_id, student_id, login_at, ip_address, user_agent, session_id)
                    VALUES (?, ?, NOW(), ?, ?, ?)
                ");
                $ins->execute([$user['id'], $stu_code, $packed_ip, $ua, $sess_id]);
            } catch (Throwable $e) {
                error_log('[student_login_log] ' . $e->getMessage());
            }
        }

        /* ---------- Role-based routing ---------- */
        $role_lc = strtolower($user['role']);

        if ($role_lc === 'student') {
            header("Location: student/dashboard.php");
            exit();
        }

        if (in_array($role_lc, ['faculty', 'professor', 'finance', 'admin', 'department'], true)) {
            header("Location: admin/department_gate.php");
            exit();
        }

        // Unknown role — fail safe.
        session_unset();
        session_destroy();
        header("Location: index.php?login_error=invalid");
        exit();

    } else {
        /* ---------- Failed attempt handling ---------- */
        $failed_attempts = $user['failed_attempts'] + 1;
        if ($failed_attempts >= 5) {
            $lockout_time = date('Y-m-d H:i:s', strtotime('+15 minutes'));
            $lock_stmt = $pdo->prepare("UPDATE users SET failed_attempts = ?, lockout_until = ? WHERE id = ?");
            $lock_stmt->execute([$failed_attempts, $lockout_time, $user['id']]);
            header("Location: index.php?login_error=locked");
        } else {
            $update_stmt = $pdo->prepare("UPDATE users SET failed_attempts = ? WHERE id = ?");
            $update_stmt->execute([$failed_attempts, $user['id']]);
            header("Location: index.php?login_error=invalid");
        }
        exit();
    }

} else {
    header("Location: index.php?login_error=invalid");
    exit();
}