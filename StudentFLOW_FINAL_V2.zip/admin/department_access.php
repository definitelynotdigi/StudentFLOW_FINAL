<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/department_access.php';

header('Content-Type: application/json');

$gate_allowed = ['faculty', 'professor', 'finance', 'admin', 'department'];
if (!in_array($current_role, $gate_allowed, true)) {
    http_response_code(403);
    echo json_encode(['status'=>'error','message'=>'Forbidden.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status'=>'error','message'=>'Method not allowed.']);
    exit();
}

verify_csrf();   // existing helper — dies with JSON 419 on failure

$action = $_POST['action'] ?? '';
$dept_id_input = trim((string)($_POST['department_id'] ?? ''));
$expected_id   = department_current_id($user_data);

/* ============ 1. SETUP CREDENTIAL ============ */
if ($action === 'setup_credential') {
    if (department_has_credential($pdo, $user_id)) {
        echo json_encode(['status'=>'error','message'=>'Access credential already exists.']);
        exit();
    }
    if ($dept_id_input === '' || $dept_id_input !== $expected_id) {
        echo json_encode(['status'=>'error','message'=>'Department ID does not match your account.']);
        exit();
    }
    $pw1 = (string)($_POST['password'] ?? '');
    $pw2 = (string)($_POST['password_confirm'] ?? '');
    if ($pw1 !== $pw2) {
        echo json_encode(['status'=>'error','message'=>'Passwords do not match.']);
        exit();
    }
    if (!department_password_ok($pw1)) {
        echo json_encode(['status'=>'error','message'=>'Password does not meet the requirements.']);
        exit();
    }

    try {
        $pdo->beginTransaction();
        $hash = password_hash($pw1, PASSWORD_BCRYPT);
        $pdo->prepare("
            INSERT INTO department_access_credentials
                (department_user_id, department_id, password_hash, is_active, last_password_change)
            VALUES (?, ?, ?, 1, NOW())
        ")->execute([$user_id, $expected_id, $hash]);

        audit_log($pdo, $user_id, 'DEPARTMENT_ACCESS_PASSWORD_CREATED',
                  "Department {$expected_id} created its access credential.");
        $pdo->commit();

        echo json_encode(['status'=>'success','message'=>'Your Department Access Password has been created successfully.']);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[dept setup] '.$e->getMessage());
        echo json_encode(['status'=>'error','message'=>"We couldn't complete the request. Please try again."]);
    }
    exit();
}

/* ============ 2. TIME IN ============ */
if ($action === 'time_in') {
    if (!department_has_credential($pdo, $user_id)) {
        echo json_encode(['status'=>'error','message'=>'Department Access Password not set up.']);
        exit();
    }
    if (department_is_locked($pdo, $user_id)) {
        echo json_encode(['status'=>'error','message'=>'Too many failed attempts. Please try again later.']);
        exit();
    }

    // Reject any attempt to Time-In as a different Department.
    if ($dept_id_input !== $expected_id) {
        department_register_failure($pdo, $user_id);
        audit_log($pdo, $user_id, 'DEPARTMENT_ACCESS_FAILED',
                  "Wrong Department ID supplied for {$expected_id}.");
        echo json_encode(['status'=>'error','message'=>'Invalid Department ID or Access Password.']);
        exit();
    }

    // Verify the Access Password.
    $s = $pdo->prepare("SELECT password_hash FROM department_access_credentials
                        WHERE department_user_id = ? AND is_active = 1 LIMIT 1");
    $s->execute([$user_id]);
    $stored = (string)$s->fetchColumn();

    if (!$stored || !password_verify((string)($_POST['password'] ?? ''), $stored)) {
        department_register_failure($pdo, $user_id);
        audit_log($pdo, $user_id, 'DEPARTMENT_ACCESS_FAILED',
                  "Wrong Access Password for {$expected_id}.");
        echo json_encode(['status'=>'error','message'=>'Invalid Department ID or Access Password.']);
        exit();
    }

    department_reset_failures($pdo, $user_id);

    // Duplicate Time-In guard.
    if (department_active_log($pdo, $user_id)) {
        echo json_encode(['status'=>'error','message'=>'You already have an active Department session.']);
        exit();
    }

    try {
        $pdo->beginTransaction();
        [$packedIp, $ua] = department_capture_meta();

        // FOR UPDATE guard against a race with a second tab.
        $pdo->prepare("SELECT id FROM users WHERE id = ? FOR UPDATE")->execute([$user_id]);

        $pdo->prepare("
            INSERT INTO department_time_logs
                (department_user_id, department_id, time_in, status, ip_address, user_agent)
            VALUES (?, ?, NOW(), 'active', ?, ?)
        ")->execute([$user_id, $expected_id, $packedIp, $ua]);

        $logId = (int)$pdo->lastInsertId();

        audit_log($pdo, $user_id, 'DEPARTMENT_TIME_IN',
                  "Department {$expected_id} successfully timed in.",
                  'department_time_log', $logId);
        $pdo->commit();

        // Fetch the server-generated time_in to display on the confirmation card.
        $row = $pdo->prepare("SELECT time_in FROM department_time_logs WHERE id = ? LIMIT 1");
        $row->execute([$logId]);
        $timeIn = $row->fetchColumn();

        // Determine the correct dashboard based on the user's role.
$next_url = 'dashboard.php';  // default for admin/department
switch ($current_role) {
    case 'faculty':
    case 'professor':
        $next_url = '../faculty/dashboard.php';
        break;
    case 'finance':
        $next_url = '../finance/dashboard.php';
        break;
    case 'admin':
    case 'department':
    default:
        $next_url = 'dashboard.php';
        break;
}

echo json_encode([
    'status'    => 'success',
    'message'   => 'Time-In recorded successfully.',
    'time_in'   => $timeIn,
    'department_id' => $expected_id,
    'log_id'    => $logId,
    'next_url'  => $next_url,
]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[dept time_in] '.$e->getMessage());
        echo json_encode(['status'=>'error','message'=>"We couldn't complete the request. Please try again."]);
    }
    exit();
}

/* ============ 3. TIME OUT ============ */
if ($action === 'time_out') {
    $log = department_active_log($pdo, $user_id);
    if (!$log) {
        echo json_encode(['status'=>'error','message'=>'No active Department session found.']);
        exit();
    }
    try {
        $pdo->beginTransaction();
        $pdo->prepare("
            UPDATE department_time_logs
            SET time_out = NOW(),
                duration_seconds = TIMESTAMPDIFF(SECOND, time_in, NOW()),
                status = 'completed'
            WHERE id = ? AND department_user_id = ? AND status = 'active'
        ")->execute([(int)$log['id'], $user_id]);

        audit_log($pdo, $user_id, 'DEPARTMENT_TIME_OUT',
                  "Department {$log['department_id']} timed out.",
                  'department_time_log', (int)$log['id']);
        $pdo->commit();

        echo json_encode(['status'=>'success','message'=>'Time-Out recorded successfully.']);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[dept time_out] '.$e->getMessage());
        echo json_encode(['status'=>'error','message'=>"We couldn't complete the request. Please try again."]);
    }
    exit();
}

/* ============ 4. ADMIN FORCE TIME-OUT (admin role only) ============ */
if ($action === 'force_time_out') {
    if ($current_role !== 'admin') {
        http_response_code(403);
        echo json_encode(['status'=>'error','message'=>'Forbidden.']);
        exit();
    }
    $logId = (int)($_POST['log_id'] ?? 0);
    $reason = trim((string)($_POST['reason'] ?? 'Manually closed by Admin'));
    if ($logId <= 0) {
        echo json_encode(['status'=>'error','message'=>'Invalid log ID.']);
        exit();
    }
    try {
        $pdo->beginTransaction();
        $s = $pdo->prepare("SELECT * FROM department_time_logs WHERE id = ? AND status='active' LIMIT 1");
        $s->execute([$logId]);
        $row = $s->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            $pdo->rollBack();
            echo json_encode(['status'=>'error','message'=>'Active log not found.']);
            exit();
        }
        $pdo->prepare("
            UPDATE department_time_logs
            SET time_out = NOW(),
                duration_seconds = TIMESTAMPDIFF(SECOND, time_in, NOW()),
                status = 'manual_closed',
                closed_by_user_id = ?,
                close_reason = ?
            WHERE id = ?
        ")->execute([$user_id, $reason, $logId]);

        audit_log($pdo, $user_id, 'DEPARTMENT_SESSION_MANUALLY_CLOSED',
                  "Admin force-closed log #{$logId} for {$row['department_id']}.",
                  'department_time_log', $logId);
        $pdo->commit();
        echo json_encode(['status'=>'success','message'=>'Department session manually closed.']);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[dept force_time_out] '.$e->getMessage());
        echo json_encode(['status'=>'error','message'=>"We couldn't complete the request. Please try again."]);
    }
    exit();
}

/* ============ 5. FORGOT ACCESS — SEND OTP ============ */
if ($action === 'forgot_send_otp') {
    // Rate limit: 3 sends per 10 minutes
    $key = 'dept_otp_rl_' . $user_id;
    $now = time();
    if (!isset($_SESSION[$key]) || !is_array($_SESSION[$key])) $_SESSION[$key] = [];
    $_SESSION[$key] = array_values(array_filter($_SESSION[$key], fn($t) => $t > ($now - 600)));
    if (count($_SESSION[$key]) >= 3) {
        echo json_encode(['status'=>'error','message'=>'Too many OTP requests. Please wait a few minutes.']);
        exit();
    }
    $_SESSION[$key][] = $now;

    // Send to the authenticated Department user's email
    $email = strtolower(trim((string)($user_data['email'] ?? '')));
    if ($email === '') {
        echo json_encode(['status'=>'error','message'=>'Your account has no email on file. Contact Admin.']);
        exit();
    }

    $otp     = sprintf('%06d', random_int(100000, 999999));
    $expires = date('Y-m-d H:i:s', strtotime('+10 minutes'));

    try {
        $pdo->prepare("
            UPDATE department_access_credentials
               SET reset_otp = ?, reset_otp_expires = ?, reset_otp_attempts = 0
             WHERE department_user_id = ? AND is_active = 1
        ")->execute([$otp, $expires, $user_id]);
    } catch (Throwable $e) {
        error_log('[dept forgot_send_otp] ' . $e->getMessage());
        echo json_encode(['status'=>'error','message'=>'Unable to generate OTP. Please try again.']);
        exit();
    }

    // Send email
    require_once __DIR__ . '/../PHPMailer/Exception.php';
    require_once __DIR__ . '/../PHPMailer/PHPMailer.php';
    require_once __DIR__ . '/../PHPMailer/SMTP.php';

    $config = require __DIR__ . '/../config.php';
    $smtp   = $config['smtp'] ?? [];

    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = $smtp['host']     ?? 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtp['username'] ?? '';
        $mail->Password   = $smtp['password'] ?? '';
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = $smtp['port']     ?? 587;
        $mail->setFrom($mail->Username, $smtp['from_name'] ?? 'StudentFLOW Portal');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Department Access Password Reset OTP';

        $safeOtp = htmlspecialchars($otp, ENT_QUOTES, 'UTF-8');
        $mail->Body = "
        <div style='font-family:Arial,sans-serif;background:#f4f6f9;padding:32px 0;'>
          <div style='max-width:520px;margin:auto;background:#fff;border-radius:16px;padding:32px;border:1px solid #e2e8f0;'>
            <h2 style='color:#800000;text-align:center;margin-top:0;'>StudentFLOW</h2>
            <p style='color:#334155;font-size:15px;text-align:center;'>Your Department Access Password reset code is:</p>
            <div style='text-align:center;margin:24px 0;'>
              <span style='display:inline-block;padding:14px 28px;background:#fff7f7;border:1px dashed #ab0a0a;border-radius:12px;font-size:34px;font-weight:800;color:#ab0a0a;letter-spacing:8px;'>{$safeOtp}</span>
            </div>
            <p style='color:#64748b;font-size:13px;text-align:center;'>This code is valid for 10 minutes.</p>
          </div>
        </div>";
        $mail->AltBody = "Department Access Password reset code: {$otp}\n\nValid for 10 minutes.";
        $mail->send();
        echo json_encode(['status'=>'success','message'=>'OTP sent to your email.']);
    } catch (Throwable $e) {
        error_log('[dept forgot_otp send] ' . $e->getMessage());
        echo json_encode(['status'=>'error','message'=>'Unable to send OTP email. Please try again.']);
    }
    exit();
}

/* ============ 6. FORGOT ACCESS — VERIFY OTP & RESET ============ */
if ($action === 'forgot_verify_reset') {
    $otp = trim((string)($_POST['otp'] ?? ''));
    $pw1 = (string)($_POST['password'] ?? '');
    $pw2 = (string)($_POST['password_confirm'] ?? '');

    if ($otp === '' || $pw1 === '') {
        echo json_encode(['status'=>'error','message'=>'OTP and new password are required.']);
        exit();
    }
    if ($pw1 !== $pw2) {
        echo json_encode(['status'=>'error','message'=>'Passwords do not match.']);
        exit();
    }
    if (!department_password_ok($pw1)) {
        echo json_encode(['status'=>'error','message'=>'Password does not meet the requirements.']);
        exit();
    }

    // Fetch the stored OTP
    $s = $pdo->prepare("
        SELECT reset_otp, reset_otp_expires, reset_otp_attempts
        FROM department_access_credentials
        WHERE department_user_id = ? AND is_active = 1 LIMIT 1
    ");
    $s->execute([$user_id]);
    $row = $s->fetch(PDO::FETCH_ASSOC);

    if (!$row || empty($row['reset_otp']) || empty($row['reset_otp_expires'])) {
        echo json_encode(['status'=>'error','message'=>'No OTP request found. Please send OTP first.']);
        exit();
    }
    if (time() > strtotime($row['reset_otp_expires'])) {
        $pdo->prepare("
            UPDATE department_access_credentials
               SET reset_otp = NULL, reset_otp_expires = NULL, reset_otp_attempts = 0
             WHERE department_user_id = ? AND is_active = 1
        ")->execute([$user_id]);
        echo json_encode(['status'=>'error','message'=>'OTP has expired. Please send a new one.']);
        exit();
    }
    if ((int)$row['reset_otp_attempts'] >= 5) {
        echo json_encode(['status'=>'error','message'=>'Too many failed attempts. Request a new OTP.']);
        exit();
    }
    if (!hash_equals((string)$row['reset_otp'], $otp)) {
        $pdo->prepare("
            UPDATE department_access_credentials
               SET reset_otp_attempts = reset_otp_attempts + 1
             WHERE department_user_id = ? AND is_active = 1
        ")->execute([$user_id]);
        echo json_encode(['status'=>'error','message'=>'Invalid OTP code.']);
        exit();
    }

    // Success — update the password
    try {
        $hash = password_hash($pw1, PASSWORD_BCRYPT);
        $pdo->prepare("
            UPDATE department_access_credentials
               SET password_hash = ?, last_password_change = NOW(),
                   failed_attempts = 0, lockout_until = NULL,
                   reset_otp = NULL, reset_otp_expires = NULL, reset_otp_attempts = 0
             WHERE department_user_id = ? AND is_active = 1
        ")->execute([$hash, $user_id]);

        audit_log($pdo, $user_id, 'DEPARTMENT_ACCESS_PASSWORD_RESET',
                  "Department {$expected_id} reset its access credential via email OTP.");

        echo json_encode(['status'=>'success','message'=>'Access password reset successfully. You can now Time In.']);
    } catch (Throwable $e) {
        error_log('[dept forgot_verify] ' . $e->getMessage());
        echo json_encode(['status'=>'error','message'=>'Reset failed. Please try again.']);
    }
    exit();
}

/* ============ 5. FORGOT ACCESS — SEND OTP ============ */
if ($action === 'forgot_send_otp') {
    // Rate limit: 3 sends per 10 minutes
    $key = 'dept_otp_rl_' . $user_id;
    $now = time();
    if (!isset($_SESSION[$key]) || !is_array($_SESSION[$key])) $_SESSION[$key] = [];
    $_SESSION[$key] = array_values(array_filter($_SESSION[$key], fn($t) => $t > ($now - 600)));
    if (count($_SESSION[$key]) >= 3) {
        echo json_encode(['status'=>'error','message'=>'Too many OTP requests. Please wait a few minutes.']);
        exit();
    }
    $_SESSION[$key][] = $now;

    // Send to the authenticated Department user's email
    $email = strtolower(trim((string)($user_data['email'] ?? '')));
    if ($email === '') {
        echo json_encode(['status'=>'error','message'=>'Your account has no email on file. Contact Admin.']);
        exit();
    }

    $otp     = sprintf('%06d', random_int(100000, 999999));
    $expires = date('Y-m-d H:i:s', strtotime('+10 minutes'));

    try {
        $pdo->prepare("
            UPDATE department_access_credentials
               SET reset_otp = ?, reset_otp_expires = ?, reset_otp_attempts = 0
             WHERE department_user_id = ? AND is_active = 1
        ")->execute([$otp, $expires, $user_id]);
    } catch (Throwable $e) {
        error_log('[dept forgot_send_otp] ' . $e->getMessage());
        echo json_encode(['status'=>'error','message'=>'Unable to generate OTP. Please try again.']);
        exit();
    }

    // Send email
    require_once __DIR__ . '/../PHPMailer/Exception.php';
    require_once __DIR__ . '/../PHPMailer/PHPMailer.php';
    require_once __DIR__ . '/../PHPMailer/SMTP.php';

    $config = require __DIR__ . '/../config.php';
    $smtp   = $config['smtp'] ?? [];

    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = $smtp['host']     ?? 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtp['username'] ?? '';
        $mail->Password   = $smtp['password'] ?? '';
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = $smtp['port']     ?? 587;
        $mail->setFrom($mail->Username, $smtp['from_name'] ?? 'StudentFLOW Portal');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Department Access Password Reset OTP';

        $safeOtp = htmlspecialchars($otp, ENT_QUOTES, 'UTF-8');
        $mail->Body = "
        <div style='font-family:Arial,sans-serif;background:#f4f6f9;padding:32px 0;'>
          <div style='max-width:520px;margin:auto;background:#fff;border-radius:16px;padding:32px;border:1px solid #e2e8f0;'>
            <h2 style='color:#800000;text-align:center;margin-top:0;'>StudentFLOW</h2>
            <p style='color:#334155;font-size:15px;text-align:center;'>Your Department Access Password reset code is:</p>
            <div style='text-align:center;margin:24px 0;'>
              <span style='display:inline-block;padding:14px 28px;background:#fff7f7;border:1px dashed #ab0a0a;border-radius:12px;font-size:34px;font-weight:800;color:#ab0a0a;letter-spacing:8px;'>{$safeOtp}</span>
            </div>
            <p style='color:#64748b;font-size:13px;text-align:center;'>This code is valid for 10 minutes.</p>
          </div>
        </div>";
        $mail->AltBody = "Department Access Password reset code: {$otp}\n\nValid for 10 minutes.";
        $mail->send();
        echo json_encode(['status'=>'success','message'=>'OTP sent to your email.']);
    } catch (Throwable $e) {
        error_log('[dept forgot_otp send] ' . $e->getMessage());
        echo json_encode(['status'=>'error','message'=>'Unable to send OTP email. Please try again.']);
    }
    exit();
}

/* ============ 6. FORGOT ACCESS — VERIFY OTP & RESET ============ */
if ($action === 'forgot_verify_reset') {
    $otp = trim((string)($_POST['otp'] ?? ''));
    $pw1 = (string)($_POST['password'] ?? '');
    $pw2 = (string)($_POST['password_confirm'] ?? '');

    if ($otp === '' || $pw1 === '') {
        echo json_encode(['status'=>'error','message'=>'OTP and new password are required.']);
        exit();
    }
    if ($pw1 !== $pw2) {
        echo json_encode(['status'=>'error','message'=>'Passwords do not match.']);
        exit();
    }
    if (!department_password_ok($pw1)) {
        echo json_encode(['status'=>'error','message'=>'Password does not meet the requirements.']);
        exit();
    }

    $s = $pdo->prepare("
        SELECT reset_otp, reset_otp_expires, reset_otp_attempts
        FROM department_access_credentials
        WHERE department_user_id = ? AND is_active = 1 LIMIT 1
    ");
    $s->execute([$user_id]);
    $row = $s->fetch(PDO::FETCH_ASSOC);

    if (!$row || empty($row['reset_otp']) || empty($row['reset_otp_expires'])) {
        echo json_encode(['status'=>'error','message'=>'No OTP request found. Please send OTP first.']);
        exit();
    }
    if (time() > strtotime($row['reset_otp_expires'])) {
        $pdo->prepare("
            UPDATE department_access_credentials
               SET reset_otp = NULL, reset_otp_expires = NULL, reset_otp_attempts = 0
             WHERE department_user_id = ? AND is_active = 1
        ")->execute([$user_id]);
        echo json_encode(['status'=>'error','message'=>'OTP has expired. Please send a new one.']);
        exit();
    }
    if ((int)$row['reset_otp_attempts'] >= 5) {
        echo json_encode(['status'=>'error','message'=>'Too many failed attempts. Request a new OTP.']);
        exit();
    }
    if (!hash_equals((string)$row['reset_otp'], $otp)) {
        $pdo->prepare("
            UPDATE department_access_credentials
               SET reset_otp_attempts = reset_otp_attempts + 1
             WHERE department_user_id = ? AND is_active = 1
        ")->execute([$user_id]);
        echo json_encode(['status'=>'error','message'=>'Invalid OTP code.']);
        exit();
    }

    try {
        $hash = password_hash($pw1, PASSWORD_BCRYPT);
        $pdo->prepare("
            UPDATE department_access_credentials
               SET password_hash = ?, last_password_change = NOW(),
                   failed_attempts = 0, lockout_until = NULL,
                   reset_otp = NULL, reset_otp_expires = NULL, reset_otp_attempts = 0
             WHERE department_user_id = ? AND is_active = 1
        ")->execute([$hash, $user_id]);

        audit_log($pdo, $user_id, 'DEPARTMENT_ACCESS_PASSWORD_RESET',
                  "Department {$expected_id} reset its access credential via email OTP.");

        echo json_encode(['status'=>'success','message'=>'Access password reset successfully. You can now Time In.']);
    } catch (Throwable $e) {
        error_log('[dept forgot_verify] ' . $e->getMessage());
        echo json_encode(['status'=>'error','message'=>'Reset failed. Please try again.']);
    }
    exit();
}

http_response_code(400);
echo json_encode(['status'=>'error','message'=>'Unknown action.']);