<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/department_access.php';

// Only non-student roles may use this gateway.
$gate_allowed = ['faculty', 'professor', 'finance', 'admin', 'department'];
if (!in_array($current_role, $gate_allowed, true)) {
    // Students (or any other unknown role) skip the gate.
    header("Location: ../index.php");
    exit();
}

$state = department_gate_state($pdo, $user_id);
if ($state === 'dashboard') {
    // Already timed in — send to the correct role dashboard.
    switch ($current_role) {
    case 'faculty':
    case 'professor':
        header("Location: ../faculty/dashboard.php");
        break;
    case 'finance':
        header("Location: ../finance/dashboard.php");
        break;
    case 'admin':
    case 'department':
    default:
        header("Location: dashboard.php");
        break;
}
    exit();
}

$dept_id  = department_current_id($user_data);
$flash    = $_SESSION['dept_flash'] ?? null;
unset($_SESSION['dept_flash']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <title>StudentFLOW | Department Access</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/dashboard-layout.css">
  <link rel="stylesheet" href="../assets/css/department-gate.css">
</head>
<body class="dept-gate-body">

<div class="dept-gate-backdrop" aria-hidden="true"></div>

<main class="dept-gate-wrap" role="dialog" aria-modal="true" aria-labelledby="deptGateTitle">

  <div class="dept-gate-card card-custom">

    <div class="dept-gate-brand">
      <img src="../assets/grc4.png" alt="GRC" height="42">
      <div class="dept-gate-brand-text">
        <strong>StudentFLOW</strong>
        <span>Department Access</span>
      </div>
    </div>

    <?php if ($flash): ?>
      <div class="alert alert-<?= htmlspecialchars($flash['type']) ?> py-2 small mb-3">
        <i class="fa-solid fa-circle-info me-1"></i>
        <?= htmlspecialchars($flash['msg']) ?>
      </div>
    <?php endif; ?>

    <?php if ($state === 'setup'): ?>
      <!-- ===================== STATE A: FIRST-TIME SETUP ===================== -->
      <h1 id="deptGateTitle" class="dept-gate-title">Department Access Setup</h1>
      <p class="dept-gate-sub">
        Welcome to StudentFLOW. Before accessing the Department Dashboard,
        you must create your unique Department Access Password.
      </p>

      <form id="deptSetupForm" autocomplete="off" novalidate>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="setup_credential">

        <label class="form-label small fw-semibold">Staff / Department ID</label>
        <div class="input-group mb-3">
          <span class="input-group-text"><i class="fa-solid fa-building-user"></i></span>
          <input type="text" class="form-control" name="department_id"
                 value="<?= htmlspecialchars($dept_id) ?>" readonly
                 aria-describedby="deptIdHelp">
        </div>
        <div id="deptIdHelp" class="form-text mb-3">
          This must match the ID on your authenticated Department account.
        </div>

        <label class="form-label small fw-semibold">Create Access Password</label>
        <div class="input-group mb-1">
          <input type="password" class="form-control" id="deptPw1" name="password"
                 placeholder="••••••••••" autocomplete="new-password" required>
          <button type="button" class="btn btn-outline-secondary password-toggle-btn"
                  data-toggle-for="deptPw1" aria-label="Show password">
            <i class="fa-solid fa-eye"></i>
          </button>
        </div>

        <label class="form-label small fw-semibold mt-3">Confirm Access Password</label>
        <div class="input-group mb-3">
          <input type="password" class="form-control" id="deptPw2" name="password_confirm"
                 placeholder="••••••••••" autocomplete="new-password" required>
          <button type="button" class="btn btn-outline-secondary password-toggle-btn"
                  data-toggle-for="deptPw2" aria-label="Show password">
            <i class="fa-solid fa-eye"></i>
          </button>
        </div>

        <ul class="dept-pw-reqs list-unstyled mb-3" id="deptPwReqs">
          <li data-req="len"><i class="fa-regular fa-circle"></i> Minimum 8 characters</li>
          <li data-req="upper"><i class="fa-regular fa-circle"></i> At least one uppercase letter</li>
          <li data-req="lower"><i class="fa-regular fa-circle"></i> At least one lowercase letter</li>
          <li data-req="num"><i class="fa-regular fa-circle"></i> At least one number</li>
          <li data-req="special"><i class="fa-regular fa-circle"></i> At least one special character</li>
        </ul>

        <button type="submit" class="btn btn-grc-action w-100 py-2 fw-bold"
                data-loading-text="Creating...">
          <i class="fa-solid fa-shield-halved me-1"></i>
          CREATE DEPARTMENT ACCESS PASSWORD
        </button>
      </form>

    <?php else: ?>
      <!-- ===================== STATE B: TIME ACCESS ===================== -->
      <h1 id="deptGateTitle" class="dept-gate-title">Staff Time Access</h1>
<p class="dept-gate-sub">
  Enter your Staff ID and Access Password, then Time In.
</p>

      <form id="deptTimeInForm" autocomplete="off" novalidate>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="time_in">

        <label class="form-label small fw-semibold">Staff / Department ID</label>
        <div class="input-group mb-3">
          <span class="input-group-text"><i class="fa-solid fa-building-user"></i></span>
          <input type="text" class="form-control" name="department_id"
                 value="<?= htmlspecialchars($dept_id) ?>" readonly>
        </div>

        <label class="form-label small fw-semibold">Access Password</label>
        <div class="input-group mb-3">
          <input type="password" class="form-control" id="deptAccessPw" name="password"
                 placeholder="••••••••••" autocomplete="current-password" required>
          <button type="button" class="btn btn-outline-secondary password-toggle-btn"
                  data-toggle-for="deptAccessPw" aria-label="Show password">
            <i class="fa-solid fa-eye"></i>
          </button>
        </div>

        <div class="dept-clock mb-3" aria-live="polite">
          <div class="dept-clock-date" id="deptClockDate">—</div>
          <div class="dept-clock-time" id="deptClockTime">--:--:-- --</div>
          <div class="dept-status">
            <span class="dept-dot dept-dot-ready"></span> Ready to Time In
          </div>
        </div>

        <button type="submit" class="btn btn-grc-action w-100 py-2 fw-bold"
                data-loading-text="Recording Time-In...">
          <i class="fa-solid fa-right-to-bracket me-1"></i> TIME IN
        </button>
      <div class="text-center mt-3">
    <a href="#" id="showForgotAccessBtn" class="small grc-link text-decoration-none fw-semibold"
       style="color:#ab0a0a;">
        <i class="fa-solid fa-key me-1"></i> Forgot Access Password?
    </a>
</div>

<!-- FORGOT ACCESS SUB-PANEL -->
<div id="forgotAccessPanel" class="mt-3 p-3 border rounded-3 bg-light" style="display:none;">
    <h6 class="fw-bold text-dark mb-2">
        <i class="fa-solid fa-shield-halved text-danger me-1"></i> Reset Department Access Password
    </h6>
    <p class="small text-muted mb-3">
        We'll email a 6-digit OTP to
        <strong><?= htmlspecialchars($user_data['email'] ?? '') ?></strong>.
    </p>

    <div id="forgotStep1">
        <button type="button" id="sendDeptOtpBtn" class="btn btn-grc-action w-100 py-2 fw-bold btn-sm">
            <i class="fa-solid fa-paper-plane me-1"></i> Send OTP to My Email
        </button>
    </div>

    <div id="forgotStep2" style="display:none;">
        <label class="form-label small fw-semibold">Enter 6-Digit OTP</label>
        <input type="text" id="deptOtpInput" class="form-control text-center fw-bold fs-5 mb-2"
               maxlength="6" placeholder="123456">

        <label class="form-label small fw-semibold mt-2">New Access Password</label>
        <div class="input-group mb-2">
            <input type="password" id="deptNewPw1" class="form-control" placeholder="••••••••••">
            <button type="button" class="btn btn-outline-secondary password-toggle-btn"
                    data-toggle-for="deptNewPw1"><i class="fa-solid fa-eye"></i></button>
        </div>

        <label class="form-label small fw-semibold">Confirm New Password</label>
        <div class="input-group mb-3">
            <input type="password" id="deptNewPw2" class="form-control" placeholder="••••••••••">
            <button type="button" class="btn btn-outline-secondary password-toggle-btn"
                    data-toggle-for="deptNewPw2"><i class="fa-solid fa-eye"></i></button>
        </div>

        <button type="button" id="resetDeptPwBtn" class="btn btn-grc-action w-100 py-2 fw-bold btn-sm">
            <i class="fa-solid fa-check me-1"></i> Reset Access Password
        </button>
    </div>
</div>
      </form>
    <?php endif; ?>

    <div class="dept-gate-footer">
      <form method="POST" action="../logout.php" class="m-0">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        <button type="submit" class="btn btn-link p-0 small text-decoration-none text-muted">
          <i class="fa-solid fa-right-from-bracket me-1"></i> Log out
        </button>
      </form>
    </div>

  </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/ui-feedback.js"></script>
<script src="../assets/js/department-gate.js"></script>
</body>
</html>