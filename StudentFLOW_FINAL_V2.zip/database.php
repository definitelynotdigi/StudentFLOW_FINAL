<?php
/* =============================================================================
   /database.php  —  Shared PDO connection
   -----------------------------------------------------------------------------
   Loads config.php EXACTLY ONCE per request (safe against require_once
   returning `1` on subsequent includes) and exposes a singleton $pdo.
   ============================================================================= */

/* ---- Load config once, cache it in a static so we always get the array ---- */
$config = (function () {
    static $cfg = null;
    if ($cfg === null) {
        $cfg = require __DIR__ . '/config.php';   // <-- plain require, no _once
        if (!is_array($cfg)) {
            $cfg = [];
        }
    }
    return $cfg;
})();

if (!isset($config['db']) || !is_array($config['db'])) {
    error_log('[DB] config.php did not return a valid "db" array. Got: ' . var_export($config, true));
    http_response_code(500);
    die("Database Connection Failed: 'db' settings are missing from config.php.");
}

$host    = $config['db']['host'] ?? 'localhost';
$dbname  = $config['db']['name'] ?? 'student_portal_db';
$user    = $config['db']['user'] ?? 'root';
$pass    = $config['db']['pass'] ?? '';
$charset = 'utf8mb4';

$dsn = "mysql:host={$host};dbname={$dbname};charset={$charset}";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    error_log('[DB] Connection failed: ' . $e->getMessage());
    http_response_code(500);
    die("Service temporarily unavailable. Please try again later.");
}