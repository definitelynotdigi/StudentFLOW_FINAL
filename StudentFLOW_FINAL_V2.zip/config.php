<?php
/* =============================================================================
   /config.php  —  Central configuration
   -----------------------------------------------------------------------------
   Loads .env BEFORE reading any getenv() value, so DB / SMTP credentials
   are always available regardless of which file requires this config first.
   ============================================================================= */

/* ---------- Minimal .env loader (no composer dependency) ---------- */
$__env_file = __DIR__ . '/.env';
if (is_file($__env_file)) {
    foreach (file($__env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;

        // Support optional "export KEY=value"
        if (stripos($line, 'export ') === 0) {
            $line = substr($line, 7);
        }

        [$k, $v] = array_pad(explode('=', $line, 2), 2, '');
        $k = trim($k);
        $v = trim($v);

        // Strip matching surrounding quotes
        if (strlen($v) >= 2) {
            $first = $v[0];
            $last  = $v[strlen($v) - 1];
            if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                $v = substr($v, 1, -1);
            }
        }

        if ($k === '') continue;
        $_ENV[$k] = $v;
        putenv("$k=$v");
    }
}
unset($__env_file);

return [
    'smtp' => [
        'host'      => getenv('SMTP_HOST')      ?: 'smtp.gmail.com',
        'username'  => getenv('SMTP_USER')      ?: '',
        'password'  => getenv('SMTP_PASS')      ?: '',
        'port'      => (int)(getenv('SMTP_PORT') ?: 587),
        'from_name' => getenv('SMTP_FROM_NAME') ?: 'StudentFLOW',
    ],
    'db' => [
        'host' => getenv('DB_HOST') ?: 'localhost',
        'name' => getenv('DB_NAME') ?: 'student_portal_db',
        'user' => getenv('DB_USER') ?: 'root',
        'pass' => getenv('DB_PASS') ?: '',
    ],
    'version'  => '1.0.0',
    'app_name' => 'StudentFLOW',
];