<?php
$app_version = 'v1.0';
?>
<footer class="sf-footer">
    <div>
        <strong>StudentFLOW</strong> &middot; Student Portal System
        &middot; <?= $app_version ?>
    </div>
    <div class="small mt-1">
        &copy; <?= date('Y') ?> Global Reciprocal Colleges. All rights reserved.
    </div>
</footer>