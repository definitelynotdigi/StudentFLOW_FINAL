<?php
/* =============================================================================
   /includes/department_access.php
   -----------------------------------------------------------------------------
   Shared helpers for the Department Time-In / Time-Out gateway.
   Required AFTER includes/auth.php (needs $pdo, $user_data, $current_role).
   ============================================================================= */

/** Canonical Department ID for the current user (users.student_id). */
function department_current_id(array $user_data): string {
    return trim((string)($user_data['student_id'] ?? ''));
}

/** Does the current Department user already have an active credential? */
function department_has_credential(PDO $pdo, int $userId): bool {
    $s = $pdo->prepare("
        SELECT 1 FROM department_access_credentials
        WHERE department_user_id = ? AND is_active = 1
        LIMIT 1
    ");
    $s->execute([$userId]);
    return (bool)$s->fetchColumn();
}

/** The current user's active time log row, or null. */
function department_active_log(PDO $pdo, int $userId): ?array {
    $s = $pdo->prepare("
        SELECT * FROM department_time_logs
        WHERE department_user_id = ? AND status = 'active'
        ORDER BY id DESC LIMIT 1
    ");
    $s->execute([$userId]);
    $row = $s->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

/**
 * Returns the destination the current Department user is allowed to be on:
 *   'setup'      -> no credential yet
 *   'time_access'-> credential exists, not timed in
 *   'dashboard'  -> timed in (dashboard is allowed)
 */
function department_gate_state(PDO $pdo, int $userId): string {
    if (!department_has_credential($pdo, $userId)) return 'setup';
    return department_active_log($pdo, $userId) ? 'dashboard' : 'time_access';
}

/** Password policy: >=8, upper, lower, digit, special. */
function department_password_ok(string $pw): bool {
    return (bool)preg_match(
        '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>]).{8,}$/',
        $pw
    );
}

/** Optional IP / UA capture (packed IP for privacy). */
function department_capture_meta(): array {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $packed = $ip !== '' ? @inet_pton($ip) : null;
    $ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
    return [$packed, $ua];
}

/**
 * Rate-limit helper for the Department Access Password.
 * 5 failures -> 15-minute lockout (mirrors authenticate.php behaviour).
 */
function department_register_failure(PDO $pdo, int $userId): array {
    $s = $pdo->prepare("SELECT failed_attempts FROM department_access_credentials
                        WHERE department_user_id = ? AND is_active = 1 LIMIT 1");
    $s->execute([$userId]);
    $current = (int)($s->fetchColumn() ?: 0);
    $next = $current + 1;

    if ($next >= 5) {
        $until = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        $pdo->prepare("UPDATE department_access_credentials
                       SET failed_attempts = ?, lockout_until = ?
                       WHERE department_user_id = ? AND is_active = 1")
            ->execute([$next, $until, $userId]);
        return ['locked' => true, 'until' => $until];
    }
    $pdo->prepare("UPDATE department_access_credentials
                   SET failed_attempts = ?
                   WHERE department_user_id = ? AND is_active = 1")
        ->execute([$next, $userId]);
    return ['locked' => false, 'until' => null];
}

function department_reset_failures(PDO $pdo, int $userId): void {
    $pdo->prepare("UPDATE department_access_credentials
                   SET failed_attempts = 0, lockout_until = NULL
                   WHERE department_user_id = ? AND is_active = 1")
        ->execute([$userId]);
}

function department_is_locked(PDO $pdo, int $userId): bool {
    $s = $pdo->prepare("
        SELECT lockout_until, NOW() AS db_now
        FROM department_access_credentials
        WHERE department_user_id = ? AND is_active = 1 LIMIT 1
    ");
    $s->execute([$userId]);
    $row = $s->fetch(PDO::FETCH_ASSOC);
    if (!$row || !$row['lockout_until']) return false;
    return $row['lockout_until'] > $row['db_now'];
}