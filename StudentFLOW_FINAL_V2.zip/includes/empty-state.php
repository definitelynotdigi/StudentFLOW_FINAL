<?php
/**
 * Usage:
 *   $empty_icon = 'fa-inbox';
 *   $empty_title = 'No Notifications';
 *   $empty_message = "You're all caught up.";
 *   include __DIR__ . '/includes/empty-state.php';
 */
?>
<div class="sf-empty-state">
    <i class="fa-solid <?= htmlspecialchars($empty_icon ?? 'fa-inbox') ?>"></i>
    <h6><?= htmlspecialchars($empty_title ?? 'Nothing Here') ?></h6>
    <p><?= htmlspecialchars($empty_message ?? 'No records to display.') ?></p>
</div>