/**
 * GRC Portal - Modern UI Feedback System v2
 * Redesigned toasts, confirms, and alerts with smooth animations.
 */

/* ============================================================
   1. TOAST NOTIFICATION SYSTEM
   ============================================================ */
const toastContainer = document.createElement('div');
toastContainer.id = 'portal-toast-container';
toastContainer.className = 'portal-toast-container';
document.body.appendChild(toastContainer);

const TOAST_ICONS = {
    success: 'fa-circle-check',
    danger:  'fa-circle-xmark',
    warning: 'fa-triangle-exclamation',
    info:    'fa-circle-info'
};

const TOAST_TITLES = {
    success: 'Success',
    danger:  'Error',
    warning: 'Warning',
    info:    'Information'
};

function showFloatingToast(title, message, type = 'info') {
    type = TOAST_ICONS[type] ? type : 'info';
    const toast = document.createElement('div');
    toast.className = `portal-toast portal-toast-${type}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'polite');

    // Progress bar for auto-dismiss
    const progress = document.createElement('div');
    progress.className = 'portal-toast-progress';

    const icon = document.createElement('div');
    icon.className = 'portal-toast-icon';
    icon.innerHTML = `<i class="fa-solid ${TOAST_ICONS[type]}"></i>`;

    const content = document.createElement('div');
    content.className = 'portal-toast-content';

    const titleEl = document.createElement('div');
    titleEl.className = 'portal-toast-title';
    titleEl.textContent = title || TOAST_TITLES[type];

    const msgEl = document.createElement('div');
    msgEl.className = 'portal-toast-message';
    msgEl.textContent = message;

    content.appendChild(titleEl);
    content.appendChild(msgEl);

    const closeBtn = document.createElement('button');
    closeBtn.className = 'portal-toast-close';
    closeBtn.setAttribute('aria-label', 'Dismiss');
    closeBtn.innerHTML = '<i class="fa-solid fa-xmark"></i>';

    const dismiss = () => {
        if (toast.classList.contains('hiding')) return;
        toast.classList.add('hiding');
        toast.addEventListener('animationend', () => toast.remove(), { once: true });
    };
    closeBtn.addEventListener('click', dismiss);

    toast.append(icon, content, closeBtn, progress);
    toastContainer.appendChild(toast);

    // Auto-dismiss after 5 seconds
    const timer = setTimeout(dismiss, 5000);
    toast.addEventListener('mouseenter', () => clearTimeout(timer));
    toast.addEventListener('mouseleave', () => setTimeout(dismiss, 1500));

    return toast;
}

/* ============================================================
   2. CONFIRMATION DIALOG
   ============================================================ */
function showConfirmDialog({
    title = 'Are you sure?',
    message = 'This action cannot be undone.',
    type = 'danger',
    confirmText = 'Confirm',
    cancelText = 'Cancel'
} = {}) {
    return new Promise((resolve) => {
        const modalId = 'portal-confirm-modal';
        document.getElementById(modalId)?.remove();

        const iconMap = {
            danger:  { icon: 'fa-triangle-exclamation', color: '#dc3545' },
            warning: { icon: 'fa-circle-exclamation',   color: '#ca8a04' },
            info:    { icon: 'fa-circle-info',          color: '#2563eb' },
            success: { icon: 'fa-circle-check',         color: '#198754' }
        };
        const conf = iconMap[type] || iconMap.info;

        const modalEl = document.createElement('div');
        modalEl.id = modalId;
        modalEl.className = 'modal fade portal-confirm-modal';
        modalEl.setAttribute('tabindex', '-1');
        modalEl.setAttribute('aria-hidden', 'true');
        modalEl.setAttribute('data-bs-backdrop', 'static');
        modalEl.innerHTML = `
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg" style="border-radius:20px;overflow:hidden;">
                    <div class="portal-confirm-body">
                        <div class="portal-confirm-icon" style="background:${conf.color}15;color:${conf.color};">
                            <i class="fa-solid ${conf.icon}"></i>
                        </div>
                        <h4 class="portal-confirm-title">${escapeHtml(title)}</h4>
                        <p class="portal-confirm-message">${escapeHtml(message)}</p>
                    </div>
                    <div class="portal-confirm-actions">
                        <button type="button" class="btn portal-confirm-btn-cancel" data-bs-dismiss="modal" id="portal-confirm-cancel">${escapeHtml(cancelText)}</button>
                        <button type="button" class="btn portal-confirm-btn-ok portal-confirm-${type}" id="portal-confirm-ok">${escapeHtml(confirmText)}</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modalEl);

        const modal = new bootstrap.Modal(modalEl);
        modal.show();

        let resolved = false;
        const finish = (val) => {
            if (resolved) return;
            resolved = true;
            resolve(val);
            modal.hide();
        };

        modalEl.querySelector('#portal-confirm-ok').addEventListener('click', () => finish(true));
        modalEl.querySelector('#portal-confirm-cancel').addEventListener('click', () => finish(false));
        modalEl.addEventListener('hidden.bs.modal', () => {
            if (!resolved) { resolved = true; resolve(false); }
            modalEl.remove();
        }, { once: true });
    });
}

/* ============================================================
   3. HELPERS
   ============================================================ */
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

function showToastFromSession(message, type) {
    if (!message) return;
    showFloatingToast(TOAST_TITLES[type] || 'Notification', message, type || 'info');
}

function setButtonLoading(button, isLoading, loadingText) {
    if (!button) return;
    if (isLoading) {
        button.dataset.originalText = button.innerHTML;
        button.innerHTML = `<i class="fa-solid fa-spinner fa-spin me-1"></i>${escapeHtml(loadingText || 'Please wait...')}`;
        button.classList.add('is-loading');
        button.disabled = true;
    } else {
        if (button.dataset.originalText) {
            button.innerHTML = button.dataset.originalText;
            delete button.dataset.originalText;
        }
        button.classList.remove('is-loading');
        button.disabled = false;
    }
}

/* ============================================================
   4. GLOBAL FORM HANDLERS
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
    document.body.addEventListener('submit', async (e) => {
        const form = e.target.closest('.js-confirm-form');
        if (form && !form.dataset.confirmed) {
            e.preventDefault();
            e.stopPropagation();
            const ok = await showConfirmDialog({
                title: form.dataset.confirmTitle || 'Confirm Action',
                message: form.dataset.confirmMessage || 'Are you sure you want to proceed?',
                type: form.dataset.confirmType || 'danger',
                confirmText: form.dataset.confirmButton || 'Confirm',
                cancelText: form.dataset.cancelButton || 'Cancel'
            });
            if (ok) {
                form.dataset.confirmed = 'true';
                form.submit();
            }
        }
    });

    // Auto loading state on plain POST forms
    document.body.addEventListener('submit', (e) => {
        const form = e.target;
        if (!(form instanceof HTMLFormElement)) return;
        if (form.classList.contains('js-confirm-form') && !form.dataset.confirmed) return;
        if (form.dataset.ajax === 'true') return;
        const btn = form.querySelector('button[type="submit"]:not([disabled])');
        if (btn) setButtonLoading(btn, true, btn.dataset.loadingText || 'Saving...');
    });
});

/* ============================================================
   5. GLOBAL 401/419 HANDLER
   ============================================================ */
(function() {
    const origFetch = window.fetch;
    window.fetch = function(...args) {
        return origFetch.apply(this, args).then(response => {
            if (response.status === 401 || response.status === 419) {
                showConfirmDialog({
                    title: 'Session Expired',
                    message: 'Your session has expired for security reasons. Please log in again.',
                    type: 'warning',
                    confirmText: 'Log In Again',
                    cancelText: 'Stay'
                }).then(ok => { if (ok) window.location.href = '/index.php?login_error=expired'; });
            }
            return response;
        });
    };
})();