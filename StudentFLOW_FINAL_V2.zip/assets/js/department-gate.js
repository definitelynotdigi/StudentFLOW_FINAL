/* =============================================================================
   /assets/js/department-gate.js
   -----------------------------------------------------------------------------
   Handles the Department Access Setup + Time-In workflow on department_gate.php.
   - Live clock (Asia/Manila)
   - Password show/hide toggles
   - Live password requirement checklist
   - AJAX submit for setup_credential + time_in (POST via fetch)
   - On success, swaps the card to the "YOU'RE TIMED IN" confirmation
   ============================================================================= */
(function () {
    'use strict';

    const API_URL = 'department_access.php';

    /* ---------- Helpers ---------- */
    function $(sel, root = document) { return root.querySelector(sel); }
    function $$(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }

    function toast(title, msg, type) {
        if (typeof window.showFloatingToast === 'function') {
            window.showFloatingToast(title, msg, type || 'info');
        } else {
            alert(title + ': ' + msg);
        }
    }

    /* ---------- Live Clock (Asia/Manila) ---------- */
    function startClock() {
        const dateEl = document.getElementById('deptClockDate');
        const timeEl = document.getElementById('deptClockTime');
        if (!dateEl || !timeEl) return;

        function tick() {
            const now = new Date();
            const opts = { timeZone: 'Asia/Manila' };
            dateEl.textContent = now.toLocaleDateString('en-US', {
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
                ...opts
            });
            timeEl.textContent = now.toLocaleTimeString('en-US', {
                hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true,
                ...opts
            });
        }
        tick();
        setInterval(tick, 1000);
    }

    /* ---------- Show/Hide Password ---------- */
    function wirePasswordToggles() {
        $$('.password-toggle-btn[data-toggle-for]').forEach(btn => {
            btn.addEventListener('click', () => {
                const inputId = btn.getAttribute('data-toggle-for');
                const input = document.getElementById(inputId);
                const icon  = btn.querySelector('i');
                if (!input) return;
                const hidden = input.type === 'password';
                input.type = hidden ? 'text' : 'password';
                if (icon) {
                    icon.classList.toggle('fa-eye', !hidden);
                    icon.classList.toggle('fa-eye-slash', hidden);
                }
                btn.setAttribute('aria-label', hidden ? 'Hide password' : 'Show password');
                input.focus();
            });
        });
    }

    /* ---------- Password Requirement Checklist ---------- */
    function wirePasswordChecklist() {
        const pw1 = document.getElementById('deptPw1');
        const list = document.getElementById('deptPwReqs');
        if (!pw1 || !list) return;

        const tests = {
            len:     v => v.length >= 8,
            upper:   v => /[A-Z]/.test(v),
            lower:   v => /[a-z]/.test(v),
            num:     v => /[0-9]/.test(v),
            special: v => /[!@#$%^&*(),.?":{}|<>]/.test(v),
        };

        function update() {
            const v = pw1.value;
            Object.entries(tests).forEach(([key, fn]) => {
                const li = list.querySelector('li[data-req="' + key + '"]');
                if (!li) return;
                const icon = li.querySelector('i');
                const ok = fn(v);
                if (icon) {
                    icon.className = ok ? 'fa-solid fa-circle-check text-success'
                                        : 'fa-regular fa-circle text-muted';
                }
            });
        }
        pw1.addEventListener('input', update);
        update();
    }

    /* ---------- AJAX submit helper ---------- */
    async function postAction(payload) {
        const fd = new FormData();
        Object.entries(payload).forEach(([k, v]) => fd.append(k, v));

        const res = await fetch(API_URL, {
            method: 'POST',
            body: fd,
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            credentials: 'same-origin',
        });

        let data;
        try {
            data = await res.json();
        } catch (e) {
            throw new Error('Server returned an invalid response.');
        }
        if (!res.ok || data.status !== 'success') {
            throw new Error(data.message || 'Request failed.');
        }
        return data;
    }

    /* ---------- Setup form ---------- */
    function wireSetupForm() {
        const form = document.getElementById('deptSetupForm');
        if (!form) return;

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = form.querySelector('button[type="submit"]');
            if (btn) { btn.disabled = true; }

            try {
                const payload = {
                    action:           'setup_credential',
                    csrf_token:       form.querySelector('input[name="csrf_token"]').value,
                    department_id:    form.querySelector('input[name="department_id"]').value,
                    password:         form.querySelector('input[name="password"]').value,
                    password_confirm: form.querySelector('input[name="password_confirm"]').value,
                };

                const res = await postAction(payload);
                toast('Setup Complete', res.message || 'Access Password created.', 'success');

                // Reload the gate page → server now returns State B (Time Access)
                setTimeout(() => { window.location.href = 'department_gate.php'; }, 900);
            } catch (err) {
                toast('Setup Failed', err.message, 'danger');
                if (btn) btn.disabled = false;
            }
        });
    }

    /* ---------- Time-In form ---------- */
    function wireTimeInForm() {
        const form = document.getElementById('deptTimeInForm');
        if (!form) return;

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = form.querySelector('button[type="submit"]');
            if (btn) { btn.disabled = true; }

            try {
                const payload = {
                    action:        'time_in',
                    csrf_token:    form.querySelector('input[name="csrf_token"]').value,
                    department_id: form.querySelector('input[name="department_id"]').value,
                    password:      form.querySelector('input[name="password"]').value,
                };

                const res = await postAction(payload);
                renderTimedIn(res);
            } catch (err) {
                toast('Time-In Failed', err.message, 'danger');
                if (btn) btn.disabled = false;
            }
        });
    }

    /* ---------- Success → "YOU'RE TIMED IN" card ---------- */
    function renderTimedIn(res) {
        const card = document.querySelector('.dept-gate-card');
        if (!card) { window.location.href = 'dashboard.php'; return; }

        const deptId  = res.department_id || '';
        const timeIn  = res.time_in || '';
        const t = new Date(timeIn.replace(' ', 'T'));

        card.innerHTML = `
            <div class="dept-gate-brand">
                <img src="../assets/grc4.png" alt="GRC" height="42">
                <div class="dept-gate-brand-text">
                    <strong>StudentFLOW</strong>
                    <span>Department Access</span>
                </div>
            </div>

            <div class="text-center">
                <div class="mb-2" style="font-size: 2.2rem; color:#198754;">
                    <i class="fa-solid fa-circle-check"></i>
                </div>
                <h1 class="dept-gate-title mb-1">YOU'RE TIMED IN</h1>
                <span class="badge bg-success-subtle text-success border border-success-subtle mb-3">ACTIVE</span>
            </div>

            <div class="dept-timedin-meta mb-3">
                <div><span>Department ID</span><strong>${escapeHtml(deptId)}</strong></div>
                <div><span>Time In</span><strong>${t.toLocaleTimeString('en-US', {hour:'2-digit',minute:'2-digit',hour12:true,timeZone:'Asia/Manila'})}</strong></div>
                <div><span>Date</span><strong>${t.toLocaleDateString('en-US', {month:'long',day:'numeric',year:'numeric',timeZone:'Asia/Manila'})}</strong></div>
                <div><span>Current Time</span><strong id="deptConfirmClock">—</strong></div>
                <div><span>Elapsed Time</span><strong id="deptElapsed">00:00:00</strong></div>
            </div>

            <button type="button" class="btn btn-grc-action w-100 py-2 fw-bold" id="deptEnterBtn">
                <i class="fa-solid fa-arrow-right-to-bracket me-1"></i> ENTER DEPARTMENT DASHBOARD
            </button>
        `;

        // Live clock + elapsed timer on the confirmation card
        const startMs = t.getTime();
        function tick() {
            const now = new Date();
            const clockEl = document.getElementById('deptConfirmClock');
            const elapsedEl = document.getElementById('deptElapsed');
            if (clockEl) {
                clockEl.textContent = now.toLocaleTimeString('en-US', {
                    hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true,timeZone:'Asia/Manila'
                });
            }
            if (elapsedEl) {
                const diff = Math.max(0, Math.floor((Date.now() - startMs) / 1000));
                const h = String(Math.floor(diff / 3600)).padStart(2,'0');
                const m = String(Math.floor((diff % 3600) / 60)).padStart(2,'0');
                const s = String(diff % 60).padStart(2,'0');
                elapsedEl.textContent = h + ':' + m + ':' + s;
            }
        }
        tick();
        setInterval(tick, 1000);

        // Go to dashboard
        const nextUrl = res.next_url || 'dashboard.php';
        const enterBtn = document.getElementById('deptEnterBtn');   // ← FIX: was never declared
        if (enterBtn) {
            enterBtn.addEventListener('click', () => {
                window.location.href = nextUrl;
            });
        }
    }

    function escapeHtml(t) {
        return String(t == null ? '' : t)
            .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
            .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }

    /* ---------- Boot ---------- */
    document.addEventListener('DOMContentLoaded', () => {
        startClock();
        wirePasswordToggles();
        wirePasswordChecklist();
        wireSetupForm();
        wireTimeInForm();
    });

        /* ---------- Forgot Access Password flow ---------- */
    function wireForgotAccess() {
        const showBtn    = document.getElementById('showForgotAccessBtn');
        const panel      = document.getElementById('forgotAccessPanel');
        const sendBtn    = document.getElementById('sendDeptOtpBtn');
        const step1      = document.getElementById('forgotStep1');
        const step2      = document.getElementById('forgotStep2');
        const resetBtn   = document.getElementById('resetDeptPwBtn');
        if (!showBtn || !panel) return;

        showBtn.addEventListener('click', (e) => {
            e.preventDefault();
            panel.style.display = panel.style.display === 'none' ? '' : 'none';
        });

        sendBtn?.addEventListener('click', async () => {
            sendBtn.disabled = true;
            sendBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i>Sending…';
            try {
                const form = document.getElementById('deptTimeInForm');
                const csrf = form.querySelector('input[name="csrf_token"]').value;
                const fd = new FormData();
                fd.append('action', 'forgot_send_otp');
                fd.append('csrf_token', csrf);

                const res = await fetch(API_URL, { method:'POST', body: fd, credentials:'same-origin' });
                const data = await res.json();
                if (!res.ok || data.status !== 'success') {
                    throw new Error(data.message || 'Failed to send OTP.');
                }
                toast('OTP Sent', data.message || 'Check your email.', 'success');
                step1.style.display = 'none';
                step2.style.display = '';
            } catch (err) {
                toast('Failed', err.message, 'danger');
                sendBtn.disabled = false;
                sendBtn.innerHTML = '<i class="fa-solid fa-paper-plane me-1"></i> Send OTP to My Email';
            }
        });

        resetBtn?.addEventListener('click', async () => {
            const otp = document.getElementById('deptOtpInput').value.trim();
            const pw1 = document.getElementById('deptNewPw1').value;
            const pw2 = document.getElementById('deptNewPw2').value;

            if (otp.length !== 6) { toast('Invalid OTP', 'Enter the 6-digit code.', 'warning'); return; }
            if (!pw1 || pw1 !== pw2) { toast('Mismatch', 'Passwords do not match.', 'warning'); return; }

            resetBtn.disabled = true;
            resetBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i>Resetting…';
            try {
                const form = document.getElementById('deptTimeInForm');
                const csrf = form.querySelector('input[name="csrf_token"]').value;
                const fd = new FormData();
                fd.append('action', 'forgot_verify_reset');
                fd.append('csrf_token', csrf);
                fd.append('otp', otp);
                fd.append('password', pw1);
                fd.append('password_confirm', pw2);

                const res = await fetch(API_URL, { method:'POST', body: fd, credentials:'same-origin' });
                const data = await res.json();
                if (!res.ok || data.status !== 'success') {
                    throw new Error(data.message || 'Reset failed.');
                }
                toast('Success', data.message, 'success');
                setTimeout(() => window.location.reload(), 1200);
            } catch (err) {
                toast('Failed', err.message, 'danger');
                resetBtn.disabled = false;
                resetBtn.innerHTML = '<i class="fa-solid fa-check me-1"></i> Reset Access Password';
            }
        });
    }

    document.addEventListener('DOMContentLoaded', wireForgotAccess);
})();