/**
 * GRC Portal - Dashboard Navigation System (Reusable)
 * -----------------------------------------------------------------------------
 * - Wires the GRC4 mobile sidebar toggle
 * - Handles mobile open/close, desktop collapse, backdrop, Escape
 * - Discovers sections dynamically from .sidebar-nav .nav-link[data-section]
 * - Preserves browser Back/Forward via hashchange
 * - Supports "overview mode" via data-overview="true"
 */
document.addEventListener('DOMContentLoaded', () => {
    const sidebar      = document.getElementById('sidebar');
    const mobileToggle = document.getElementById('mobileSidebarToggle');
    const mainContent  = document.querySelector('.main-content');
    const headerTitle  = document.querySelector('.top-header .header-title');

    /* ------------------------------------------------------------------
       0. Hard requirement: sidebar + GRC4 must exist
       ------------------------------------------------------------------ */
    if (!sidebar) return;

    /* ------------------------------------------------------------------
       1. Mobile backdrop (create if missing)
       ------------------------------------------------------------------ */
    let backdrop = document.querySelector('.sidebar-backdrop');
    if (!backdrop) {
        backdrop = document.createElement('div');
        backdrop.className = 'sidebar-backdrop';
        document.body.appendChild(backdrop);
    }

    /* ------------------------------------------------------------------
       2. Open / close helpers
       ------------------------------------------------------------------ */
    function openMobileSidebar() {
        sidebar.classList.add('show');
        backdrop.classList.add('show');
        document.body.classList.add('sidebar-open');
        if (mobileToggle) mobileToggle.setAttribute('aria-expanded', 'true');
    }

    function closeMobileSidebar() {
        sidebar.classList.remove('show');
        backdrop.classList.remove('show');
        document.body.classList.remove('sidebar-open');
        if (mobileToggle) mobileToggle.setAttribute('aria-expanded', 'false');
    }

    function toggleSidebar() {
        const isMobile = window.innerWidth < 992;
        if (isMobile) {
            if (sidebar.classList.contains('show')) {
                closeMobileSidebar();
            } else {
                openMobileSidebar();
            }
        } else {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        }
    }

    /* ------------------------------------------------------------------
       3. GRC4 listener — THE critical piece
       ------------------------------------------------------------------ */
    if (mobileToggle) {
        mobileToggle.addEventListener('click', () => {
            if (window.innerWidth < 992) {
                openMobileSidebar();
            } else {
                toggleSidebar();
            }
        });
    }

    /* ------------------------------------------------------------------
       4. GRC2, backdrop, Escape
       ------------------------------------------------------------------ */
    const logoBtn = document.getElementById('sidebarLogoToggle');
    if (logoBtn) logoBtn.addEventListener('click', toggleSidebar);

    backdrop.addEventListener('click', closeMobileSidebar);

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && sidebar.classList.contains('show')) {
            closeMobileSidebar();
        }
    });

    /* ------------------------------------------------------------------
       5. Restore desktop collapsed state on load
       ------------------------------------------------------------------ */
    if (window.innerWidth >= 992 && localStorage.getItem('sidebarCollapsed') === 'true') {
        sidebar.classList.add('collapsed');
    }

    /* ------------------------------------------------------------------
       6. Section discovery (optional — sidebar works without it)
       ------------------------------------------------------------------ */
    const navLinks = Array.from(
        document.querySelectorAll('.sidebar-nav .nav-link[data-section]')
    );

    const sectionMap = new Map();
    navLinks.forEach(link => {
        const id = link.dataset.section;
        if (!id) return;
        const el = document.getElementById(id);
        if (el) sectionMap.set(id, el);
    });

    /* ------------------------------------------------------------------
       7. showSection — defined BEFORE nav click handler uses it
       ------------------------------------------------------------------ */
    function showSection(sectionId, opts) {
        opts = opts || {};
        const updateHash = opts.updateHash !== false;
        const scrollTop  = opts.scrollTop !== false;

        const target = sectionMap.get(sectionId);
        if (!target) return false;

        const clickedLink = navLinks.find(l => l.dataset.section === sectionId);
        const isOverview  = clickedLink && clickedLink.dataset.overview === 'true';

        if (isOverview) {
            sectionMap.forEach(el => el.classList.add('active'));
        } else {
            sectionMap.forEach(el => el.classList.remove('active'));
            target.classList.add('active');
        }

        navLinks.forEach(link => {
            const isActive = link.dataset.section === sectionId;
            link.classList.toggle('active', isActive);
            if (isActive) link.setAttribute('aria-current', 'page');
            else          link.removeAttribute('aria-current');
        });

        if (headerTitle) {
            const labelEl = clickedLink ? clickedLink.querySelector('span') : null;
            if (labelEl) headerTitle.textContent = labelEl.textContent.trim();
        }

        if (updateHash) {
            const newHash = '#' + sectionId;
            if (window.location.hash !== newHash) {
                history.pushState(null, '', newHash);
            }
        }

        if (scrollTop && mainContent) mainContent.scrollTop = 0;

        // Auto-close drawer when a nav item is picked on mobile
        if (window.innerWidth < 992) {
            closeMobileSidebar();
        }

        return true;
    }

    /* ------------------------------------------------------------------
       8. Nav click handlers
       ------------------------------------------------------------------ */
    navLinks.forEach(link => {
        link.addEventListener('click', e => {
            const id = link.dataset.section;
            if (!id) return;
            if (!sectionMap.has(id)) return;    // profile / logout links
            e.preventDefault();
            showSection(id, { updateHash: true });
        });
    });

    /* ------------------------------------------------------------------
       9. Default / hash resolution
       ------------------------------------------------------------------ */
    function getDefaultSectionId() {
        if (sectionMap.has('dashboard')) return 'dashboard';
        for (const link of navLinks) {
            if (sectionMap.has(link.dataset.section)) return link.dataset.section;
        }
        return null;
    }

    function resolveHash() {
    // Always prioritize a valid hash from the URL.
    const hash = window.location.hash.replace(/^#/, '');
    if (hash && sectionMap.has(hash)) {
        return hash;
    }
    // Only fall back to the default section if the hash is missing or invalid.
    return getDefaultSectionId();
}

    function applyFromHash(scrollTop) {
        const id = resolveHash();
        if (!id) return;
        showSection(id, { updateHash: false, scrollTop: scrollTop !== false });
    }

    window.addEventListener('hashchange', () => applyFromHash(true));
    window.addEventListener('popstate',  () => applyFromHash(true));

    const initialId = resolveHash();
    if (initialId) {
        const wantHash = '#' + initialId;
        if (window.location.hash !== wantHash) {
            history.replaceState(null, '', wantHash);
        }
        showSection(initialId, { updateHash: false, scrollTop: false });
    }

    /* ------------------------------------------------------------------
       10. Reset sidebar state when crossing the mobile/desktop breakpoint
       ------------------------------------------------------------------ */
    let lastIsMobile = window.innerWidth < 992;
    window.addEventListener('resize', () => {
        const isMobile = window.innerWidth < 992;
        if (isMobile !== lastIsMobile) {
            lastIsMobile = isMobile;
            closeMobileSidebar();
            sidebar.classList.remove('collapsed');
            if (!isMobile && localStorage.getItem('sidebarCollapsed') === 'true') {
                sidebar.classList.add('collapsed');
            }
        }
    });
});