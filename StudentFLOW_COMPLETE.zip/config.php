<?php
return [
    'smtp' => [
    'host'      => 'smtp.elasticemail.com',
    'username'  => 'swaqqerkaye017@gmail.com',
    'password'  => '71726714E2714367F1E37F0D9EBC94D61E4F',
    'port'      => 2525,
    'from_name' => 'StudentFLOW',
],
    'db' => [
        'host' => getenv('DB_HOST') ?: 'sql312.infinityfree.com',
        'name' => getenv('DB_NAME') ?: 'if0_43057572_student_portal_db',
        'user' => getenv('DB_USER') ?: 'if0_43057572',
        'pass' => getenv('DB_PASS') ?: 'TVy2P3fkIQ',
    ],
];